#include <iostream>
#include <cstdlib>
using namespace std;

/*Stats given base stats:
Hit Points:
( (2 * BaseStat) * Level/100 ) + 10 + Level

Attack, Defense, Speed, Sp. Attack, Sp. Defense:
(((2 * BaseStat ) * Level/100 ) + 5) * Nature Value

Damage:
((((2 Level / 5 + 2) AttackStat AttackPower / DefenseStat) / 50) + 2)*Modifier */

//IVs and EVs not implemented
//Nature and Damage Modifier to be implemented

class pkmn{
	public:
		string name;
		string moveset[4];
		string moveType[4];
		int movePwr[4];
		int lvl;
		int baseHP;
		int baseATK;
		int baseDEF;
		int baseSATK;
		int baseSDEF;
		int baseSPD;
		int HP;
		int ATK;
		int DEF;
		int SATK;
		int SDEF;
		int SPD;
		
		void setAllStats(int lvl, int bHP, int bATK, int bDEF, int bSATK, int bSDEF, int bSPD){
			HP=setHP(bHP, lvl);
			ATK=setStat(bATK, lvl);
			DEF=setStat(bDEF, lvl);
			SATK=setStat(bSATK, lvl);
			SDEF=setStat(bSDEF, lvl);
			SPD=setStat(bSPD, lvl);
		}
		
		int setHP(int bHP, int lvl){
			int HP=static_cast<int>(((2*bHP*lvl)/100)+10+lvl);
			return HP;
		}
		
		int setStat(int bStat, int lvl){
			int stat=static_cast<int>(((2*bStat*lvl)/100)+5);
			return stat;
		}
		
		int moveInd(string move,string moveset[4],string moveType[4]){
			//Search for index of move in moveset
			int i=0;
			for (; i<4; ++i){
				if(move == moveset[i]) break;
			}
			return i;
		}
		
		int dmg(int i, int lvl, int movePwr[4], int A, int D){
			int t=static_cast<int>(((2*lvl / 5 + 2) * movePwr[i] * (A/D))/50 + 2);
			return t;
		}
};

/*int currDmg(string currMove, string pkmnMoves[4], int pkmnMovesPwr[4]){
	int i=0;
	for (; i<4; ++i){
		if(currMove == pkmnMoves[i]) break;
	}
	return pkmnMovesPwr[i];
}*/

int main(){
	pkmn pkmn2;
	pkmn2.name="PIKACHU";
	pkmn2.moveset[0]="Thunder Shock";
	pkmn2.moveset[1]="Growl";
	pkmn2.moveset[2]="Tail Whip";
	pkmn2.moveset[3]="-";
	pkmn2.moveType[0]="Physical";
	pkmn2.moveType[1]="ATK";
	pkmn2.moveType[2]="DEF";
	pkmn2.moveType[3]="Physical";
	pkmn2.movePwr[0]=40;
	pkmn2.movePwr[1]=2/3;
	pkmn2.movePwr[2]=2/3;
	pkmn2.movePwr[3]=0;
	pkmn2.lvl=5;
	pkmn2.baseHP=35;
	pkmn2.baseATK=55;
	pkmn2.baseDEF=30;
	pkmn2.baseSATK=50;
	pkmn2.baseSDEF=40;
	pkmn2.baseSPD=90;
	pkmn2.setAllStats(pkmn2.lvl,pkmn2.baseHP,pkmn2.baseATK,pkmn2.baseDEF,pkmn2.baseSATK,pkmn2.baseSDEF,pkmn2.baseSPD);
	
	cout << "A wild " << pkmn2.name << " appeared!" << endl;
	
	pkmn pkmn1;
	pkmn1.name="CHARMANDER";
	pkmn1.moveset[0]="Scratch";
	pkmn1.moveset[1]="Growl";
	pkmn1.moveset[2]="-";
	pkmn1.moveset[3]="-";
	pkmn1.moveType[0]="Physical";
	pkmn1.moveType[1]="ATK";
	pkmn1.moveType[2]="Physical";
	pkmn1.moveType[3]="Physical";
	pkmn1.movePwr[0]=40;
	pkmn1.movePwr[1]=2/3;
	pkmn1.movePwr[2]=0;
	pkmn1.movePwr[3]=0;
	pkmn1.lvl=5;
	pkmn1.baseHP=39;
	pkmn1.baseATK=52;
	pkmn1.baseDEF=43;
	pkmn1.baseSATK=60;
	pkmn1.baseSDEF=50;
	pkmn1.baseSPD=65;
	pkmn1.setAllStats(pkmn1.lvl,pkmn1.baseHP,pkmn1.baseATK,pkmn1.baseDEF,pkmn1.baseSATK,pkmn1.baseSDEF,pkmn1.baseSPD);
	
	/*DEBUG:
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << pkmn1.name << endl;
	cout << pkmn1.lvl << endl;
	cout << pkmn1.baseHP << endl;
	cout << pkmn1.baseATK << endl;
	cout << pkmn1.baseDEF << endl;
	cout << pkmn1.baseSATK << endl;
	cout << pkmn1.baseSDEF << endl;
	cout << pkmn1.baseSPD << endl;
	cout << pkmn1.HP << endl;
	cout << pkmn1.ATK << endl;
	cout << pkmn1.DEF << endl;
	cout << pkmn1.SATK << endl;
	cout << pkmn1.SDEF << endl;
	cout << pkmn1.SPD << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << pkmn2.name << endl;
	cout << pkmn2.lvl << endl;
	cout << pkmn2.baseHP << endl;
	cout << pkmn2.baseATK << endl;
	cout << pkmn2.baseDEF << endl;
	cout << pkmn2.baseSATK << endl;
	cout << pkmn2.baseSDEF << endl;
	cout << pkmn2.baseSPD << endl;
	cout << pkmn2.HP << endl;
	cout << pkmn2.ATK << endl;
	cout << pkmn2.DEF << endl;
	cout << pkmn2.SATK << endl;
	cout << pkmn2.SDEF << endl;
	cout << pkmn2.SPD << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;*/
	
	cout << "Go! " << pkmn1.name << "!" << endl;
	
	while (pkmn2.HP>0 && pkmn1.HP>0){
		cout << "---------------------------------" << endl;
		cout << pkmn2.name << "'s HP: " << pkmn2.HP << endl;
		cout << pkmn1.name << "'s HP: " << pkmn1.HP << endl;
		cout << "---------------------------------" << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << pkmn1.name << endl;
		cout << "HP: " << pkmn1.HP << " ATK: " << pkmn1.ATK << " DEF: " << pkmn1.DEF << endl;
		cout << "SATK: " << pkmn1.SATK << " SDEF: " << pkmn1.SDEF << " SPD: " << pkmn1.SPD << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << pkmn2.name << endl;
		cout << "HP: " << pkmn2.HP << " ATK: " << pkmn2.ATK << " DEF: " << pkmn2.DEF << endl;
		cout << "SATK: " << pkmn2.SATK << " SDEF: " << pkmn2.SDEF << " SPD: " << pkmn2.SPD << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		
		cout << "What will " << pkmn1.name << " do?" << endl;
		
		/*cout << pkmn1.name << "'s Moveset: " << endl;
		for (int i=0; i<4; ++i) cout << pkmnMoves[i] << endl;*/
		
		string currMove;
		cin >> currMove;
		cout << pkmn1.name << " used " << currMove << "!" << endl;
		int ind=pkmn1.moveInd(currMove,pkmn1.moveset,pkmn1.moveType);
		string type=pkmn1.moveType[ind];
		if(type=="Physical"){
			pkmn2.HP-=pkmn1.dmg(ind, pkmn1.lvl, pkmn1.movePwr, pkmn1.ATK, pkmn2.DEF);
		}
		else if(type=="Special"){
			pkmn2.HP-=pkmn1.dmg(ind, pkmn1.lvl, pkmn1.movePwr, pkmn1.SATK, pkmn2.SDEF);
		}
		else{ //Status
			if (type=="ATK") pkmn1.ATK=static_cast<int>(pkmn1.ATK*2/3);
			else if (type=="DEF") pkmn1.DEF=static_cast<int>(pkmn1.DEF*2/3);
			else if (type=="SATK") pkmn1.SATK=static_cast<int>(pkmn1.SATK*2/3);
			else if (type=="SDEF") pkmn1.SDEF=static_cast<int>(pkmn1.SDEF*2/3);
			else pkmn1.SPD=static_cast<int>(pkmn1.SPD*2/3);
		}
		
		if(pkmn2.HP>0) {
			int ind=rand() % 4;
			cout << pkmn2.name << " used " << pkmn2.moveset[ind] << "!" << endl;
			string type=pkmn2.moveType[ind];
			if(type=="Physical"){
				pkmn1.HP-=pkmn2.dmg(ind, pkmn2.lvl, pkmn2.movePwr, pkmn2.ATK, pkmn1.DEF);
			}
			else if(type=="Special"){
				pkmn1.HP-=pkmn2.dmg(ind, pkmn2.lvl, pkmn2.movePwr, pkmn2.SATK, pkmn1.SDEF);
			}
			else{ //Status
				if (type=="ATK") pkmn1.ATK=static_cast<int>(pkmn1.ATK*2/3);
				else if (type=="DEF") pkmn1.DEF=static_cast<int>(pkmn1.DEF*2/3);
				else if (type=="SATK") pkmn1.SATK=static_cast<int>(pkmn1.SATK*2/3);
				else if (type=="SDEF") pkmn1.SDEF=static_cast<int>(pkmn1.SDEF*2/3);
				else pkmn1.SPD=static_cast<int>(pkmn1.SPD*2/3);
			}
		}
	}
	
	if (pkmn2.HP<=0){
		cout << "The wild " << pkmn2.name << " fainted!" << endl;
	}
	else{
		cout << pkmn1.name << " fainted!" << endl;
	}
	return 0;
}
