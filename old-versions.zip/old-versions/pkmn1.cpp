#include <iostream>
using namespace std;

/*Stats given base stats:
Hit Points:
( (IV + 2 * BaseStat + (EV/4) ) * Level/100 ) + 10 + Level

Attack, Defense, Speed, Sp. Attack, Sp. Defense:
(((IV + 2 * BaseStat + (EV/4) ) * Level/100 ) + 5) * Nature Value

Damage:
((((2 Level / 5 + 2) AttackStat AttackPower / DefenseStat) / 50) + 2)*Modifier */

int currDmg(string currMove, string pkmnMoves[4], int pkmnMovesPwr[4]){
	int i=0;
	for (; i<4; ++i){
		if(currMove == pkmnMoves[i]) break;
	}
	return pkmnMovesPwr[i];
}

int main(){
	string enemyName="PIKACHU";
	int enemyHP=35;
	int enemyLvl=5;
	
	cout << "A wild " << enemyName << " appeared!" << endl;
	
	string pkmnName="CHARMANDER";
	string pkmnMoves[4]={"Scratch", "Growl", "-", "-"};
	int pkmnMovesPwr[4]={40, 0, -10, -10};
	int pkmnHP=39;
	int pkmnLvl=5;
	
	cout << "Go! " << pkmnName << "!" << endl;
	
	while (enemyHP>0 && pkmnHP>0){
		cout << "---------------------------------" << endl;
		cout << enemyName << "'s HP: " << enemyHP << endl;
		cout << pkmnName << "'s HP: " << pkmnHP << endl;
		cout << "---------------------------------" << endl;
		
		cout << "What will " << pkmnName << " do?" << endl;
		/*cout << pkmnName << "'s Moveset: " << endl;
		for (int i=0; i<4; ++i) cout << pkmnMoves[i] << endl;*/
		string currMove;
		cin >> currMove;
		cout << pkmnName << " used " << currMove << "!" << endl;
		enemyHP-= 4*currDmg(currMove, pkmnMoves, pkmnMovesPwr)/50 + 2;
		
		if(enemyHP>0) {
		cout << enemyName << " used Thunder Shock!" << endl;
		pkmnHP-= 5;
		//damage=((2*pkmnLvl / 5 + 2) * movePwr * (pkmnAtt/enemyDef))/50 + 2;
		}
	}
	
	if (!enemyHP>0){
		cout << "The wild " << enemyName << " fainted!" << endl;
	}
	else{
		cout << pkmnName << " fainted!" << endl;
	}
}
