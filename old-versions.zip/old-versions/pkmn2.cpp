#include <iostream>
using namespace std;

/*Stats given base stats:
Hit Points:
( (2 * BaseStat) * Level/100 ) + 10 + Level

Attack, Defense, Speed, Sp. Attack, Sp. Defense:
(((2 * BaseStat ) * Level/100 ) + 5) * Nature Value

Damage:
((((2 Level / 5 + 2) AttackStat AttackPower / DefenseStat) / 50) + 2)*Modifier */

//IVs and EVs not implemented
//Nature to be implemented

class pkmn{
	public:
		string name;
		string moveset[4];
		int movePwr[4];
		int lvl;
		int baseHP;
		int baseATK;
		int baseDEF;
		int baseSATK;
		int baseSDEF;
		int baseSPD;
		int HP;
		int ATK;
		int DEF;
		int SATK;
		int SDEF;
		int SPD;
		
		int setHP(int bHP, int lvl){
			int HP=static_cast<int>(((2*bHP*lvl)/100)+10+lvl);
			return HP;
		}
		
		int setStat(int bStat, int lvl){
			int stat=static_cast<int>(((2*bStat*lvl)/100)+5);
			return stat;
		}
};

int currDmg(string currMove, string pkmnMoves[4], int pkmnMovesPwr[4]){
	int i=0;
	for (; i<4; ++i){
		if(currMove == pkmnMoves[i]) break;
	}
	return pkmnMovesPwr[i];
}

int main(){
	pkmn pikachu;
	pikachu.name="PIKACHU";
	pikachu.moveset[0]="Thunder Shock";
	pikachu.moveset[1]="Growl";
	pikachu.moveset[2]="Tail Whip";
	pikachu.moveset[3]="-";
	pikachu.movePwr[0]=40;
	pikachu.movePwr[1]=0;
	pikachu.movePwr[2]=0;
	pikachu.movePwr[3]=0;
	pikachu.lvl=5;
	pikachu.baseHP=35;
	pikachu.baseATK=55;
	pikachu.baseDEF=30;
	pikachu.baseSATK=50;
	pikachu.baseSDEF=40;
	pikachu.baseSPD=90;
	
	int enemyHP=35;
	int enemyLvl=5;
	
	cout << "A wild " << pikachu.name << " appeared!" << endl;
	
	pkmn charmander;
	charmander.name="CHARMANDER";
	charmander.moveset[0]="Scratch";
	charmander.moveset[1]="Growl";
	charmander.moveset[2]="-";
	charmander.moveset[3]="-";
	charmander.movePwr[0]=40;
	charmander.movePwr[1]=0;
	charmander.movePwr[2]=0;
	charmander.movePwr[3]=0;
	charmander.lvl=5;
	charmander.baseHP=39;
	charmander.baseATK=52;
	charmander.baseDEF=43;
	charmander.baseSATK=60;
	charmander.baseSDEF=50;
	charmander.baseSPD=65;
	charmander.HP=charmander.setHP(charmander.baseHP, charmander.lvl);
	charmander.ATK=charmander.setStat(charmander.baseATK, charmander.lvl);
	charmander.DEF=charmander.setStat(charmander.baseDEF, charmander.lvl);
	charmander.SATK=charmander.setStat(charmander.baseSATK, charmander.lvl);
	charmander.SDEF=charmander.setStat(charmander.baseSDEF, charmander.lvl);
	charmander.SPD=charmander.setStat(charmander.baseSPD, charmander.lvl);
	
	//DEBUG:
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << charmander.name << endl;
	cout << charmander.lvl << endl;
	cout << charmander.baseHP << endl;
	cout << charmander.baseATK << endl;
	cout << charmander.baseDEF << endl;
	cout << charmander.baseSATK << endl;
	cout << charmander.baseSDEF << endl;
	cout << charmander.baseSPD << endl;
	cout << charmander.HP << endl;
	cout << charmander.ATK << endl;
	cout << charmander.DEF << endl;
	cout << charmander.SATK << endl;
	cout << charmander.SDEF << endl;
	cout << charmander.SPD << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	
	cout << "Go! " << charmander.name << "!" << endl;
	
	while (enemyHP>0 && charmander.HP>0){
		cout << "---------------------------------" << endl;
		cout << pikachu.name << "'s HP: " << enemyHP << endl;
		cout << charmander.name << "'s HP: " << charmander.HP << endl;
		cout << "---------------------------------" << endl;
		
		cout << "What will " << charmander.name << " do?" << endl;
		/*cout << charmander.name << "'s Moveset: " << endl;
		for (int i=0; i<4; ++i) cout << pkmnMoves[i] << endl;*/
		string currMove;
		cin >> currMove;
		cout << charmander.name << " used " << currMove << "!" << endl;
		enemyHP-= 4*currDmg(currMove, charmander.moveset, charmander.movePwr)/50 + 2;
		
		if(enemyHP>0) {
		cout << pikachu.name << " used Thunder Shock!" << endl;
		charmander.HP-= 5;
		//damage=((2*pkmnLvl / 5 + 2) * movePwr * (pkmnAtt/enemyDef))/50 + 2;
		}
	}
	
	if (!enemyHP>0){
		cout << "The wild " << pikachu.name << " fainted!" << endl;
	}
	else{
		cout << charmander.name << " fainted!" << endl;
	}
	return 0;
}
