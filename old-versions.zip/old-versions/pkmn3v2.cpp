#include <iostream>
#include <cstdlib>
using namespace std;

/*Stats given base stats:
Hit Points:
( (2 * BaseStat) * Level/100 ) + 10 + Level

Attack, Defense, Speed, Sp. Attack, Sp. Defense:
(((2 * BaseStat ) * Level/100 ) + 5) * Nature Value

Damage:
((((2 Level / 5 + 2) AttackStat AttackPower / DefenseStat) / 50) + 2)*Modifier */

//IVs and EVs not implemented
//Nature and Damage Modifier to be implemented
//ACC and EVA to be implemented
//types to be implemented
//sstream getline to be implemented

/*Added in v3: 
-SPD determines first to attack
-Stats can not be lowered to 0
-Removed base stat objects
-Optimized setAllStats into constructors
-Optimized adding moves into setMove function*/

class pkmn{
	public:
		string name;
		string moveset[4];
		string moveType[4];
		int movePwr[4];
		int lvl;
		int HP;
		int ATK;
		int DEF;
		int SATK;
		int SDEF;
		int SPD;
		
		pkmn(string pName, int pLvl, int bHP, int bATK, int bDEF, int bSATK, int bSDEF, int bSPD){
			name=pName;
			lvl=pLvl;
			HP=setHP(bHP, lvl);
			ATK=setStat(bATK, lvl);
			DEF=setStat(bDEF, lvl);
			SATK=setStat(bSATK, lvl);
			SDEF=setStat(bSDEF, lvl);
			SPD=setStat(bSPD, lvl);
		}
		
		void setMove(int ind, string move, string type, int pwr){
			moveset[ind]=move;
			moveType[ind]=type;
			movePwr[ind]=pwr;
		}
		
		int setHP(int bHP, int lvl){
			int HP=static_cast<int>(((2*bHP*lvl)/100)+10+lvl);
			return HP;
		}
		
		int setStat(int bStat, int lvl){
			int stat=static_cast<int>(((2*bStat*lvl)/100)+5);
			return stat;
		}
		
		int moveInd(string move,string moveset[4],string moveType[4]){
			//Search for index of move in moveset
			int i=0;
			for (; i<4; ++i){
				if(move == moveset[i]) break;
			}
			return i;
		}
		
		int dmg(int i, int lvl, int movePwr[4], int A, int D){
			int t=static_cast<int>(((2*lvl / 5 + 2) * movePwr[i] * (A/D))/50 + 2);
			return t;
		}
};

int main(){
	/*
	pkmn pkmn2 ("PIKACHU",5,35,55,30,50,40,90);
	pkmn2.setMove(0, "Thunder Shock", "Physical", 40);
	pkmn2.setMove(1, "Growl", "ATK", 2/3);
	pkmn2.setMove(2, "Tail Whip", "DEF", 2/3);
	pkmn2.setMove(3, "-", "Physical", 40);
	*/
	
	/*
	pkmn pkmn2 ("CHARIZARD",20,78,84,78,109,85,100);
	pkmn2.setMove(0, "Dragon Claw", "Physical", 80);
	pkmn2.setMove(1, "Air Slash", "Special", 75);
	pkmn2.setMove(2, "Shadow Claw", "Physical", 70);
	pkmn2.setMove(3, "Growl", "ATK", 2/3);
	*/
	
	//----------------------------------------------------------------------------------------------------------------------------
	
	//pkmn pkmn1/2 (name, lvl, base HP, base ATK, base DEF, base SATK, base SDEF, base SPD)
	pkmn pkmn2 ("BULBASAUR",5,45,49,49,65,65,45);
	pkmn2.setMove(0, "Tackle", "Physical", 40);
	pkmn2.setMove(1, "Growl", "ATK", 2/3);
	pkmn2.setMove(2, "-", "Physical", 40);
	pkmn2.setMove(3, "-", "Physical", 40);
	
	pkmn pkmn1 ("CHARMANDER", 5, 39, 52, 42, 60, 50, 65);
	pkmn1.setMove(0, "Scratch", "Physical", 40);
	pkmn1.setMove(1, "Growl", "ATK", 2/3);
	pkmn1.setMove(2, "-", "Physical", 40);
	pkmn1.setMove(3, "-", "Physical", 40);
	
	/*DEBUG:
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << pkmn1.name << endl;
	cout << pkmn1.lvl << endl;
	cout << pkmn1.baseHP << endl;
	cout << pkmn1.baseATK << endl;
	cout << pkmn1.baseDEF << endl;
	cout << pkmn1.baseSATK << endl;
	cout << pkmn1.baseSDEF << endl;
	cout << pkmn1.baseSPD << endl;
	cout << pkmn1.HP << endl;
	cout << pkmn1.ATK << endl;
	cout << pkmn1.DEF << endl;
	cout << pkmn1.SATK << endl;
	cout << pkmn1.SDEF << endl;
	cout << pkmn1.SPD << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << pkmn2.name << endl;
	cout << pkmn2.lvl << endl;
	cout << pkmn2.baseHP << endl;
	cout << pkmn2.baseATK << endl;
	cout << pkmn2.baseDEF << endl;
	cout << pkmn2.baseSATK << endl;
	cout << pkmn2.baseSDEF << endl;
	cout << pkmn2.baseSPD << endl;
	cout << pkmn2.HP << endl;
	cout << pkmn2.ATK << endl;
	cout << pkmn2.DEF << endl;
	cout << pkmn2.SATK << endl;
	cout << pkmn2.SDEF << endl;
	cout << pkmn2.SPD << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;*/
	
	cout << "A wild " << pkmn2.name << " appeared!" << endl;
	cout << "Go! " << pkmn1.name << "!" << endl;
	
	bool PKMN2FIRST;
	
	PKMN2F3:
	while (pkmn2.HP>0 && pkmn1.HP>0){
		int ind;
		
		cout << "---------------------------------" << endl;
		cout << pkmn2.name << "'s HP: " << pkmn2.HP << endl;
		cout << pkmn1.name << "'s HP: " << pkmn1.HP << endl;
		cout << "---------------------------------" << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << pkmn1.name << endl;
		cout << "HP: " << pkmn1.HP << " ATK: " << pkmn1.ATK << " DEF: " << pkmn1.DEF << endl;
		cout << "SATK: " << pkmn1.SATK << " SDEF: " << pkmn1.SDEF << " SPD: " << pkmn1.SPD << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << pkmn2.name << endl;
		cout << "HP: " << pkmn2.HP << " ATK: " << pkmn2.ATK << " DEF: " << pkmn2.DEF << endl;
		cout << "SATK: " << pkmn2.SATK << " SDEF: " << pkmn2.SDEF << " SPD: " << pkmn2.SPD << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		
		if (pkmn2.SPD>pkmn1.SPD) {
			PKMN2FIRST=true;
			goto PKMN2F1;
		}
		PKMN2F2:
		
		if(pkmn1.HP>0) {
			cout << "What will " << pkmn1.name << " do?" << endl;
			
			/*cout << pkmn1.name << "'s Moveset: " << endl;
			for (int i=0; i<4; ++i) cout << pkmnMoves[i] << endl;*/
			
			string currMove;
			cin >> currMove;
			cout << pkmn1.name << " used " << currMove << "!" << endl;
			int ind=pkmn1.moveInd(currMove,pkmn1.moveset,pkmn1.moveType);
			string type=pkmn1.moveType[ind];
			if(type=="Physical"){
				pkmn2.HP-=pkmn1.dmg(ind, pkmn1.lvl, pkmn1.movePwr, pkmn1.ATK, pkmn2.DEF);
			}
			else if(type=="Special"){
				pkmn2.HP-=pkmn1.dmg(ind, pkmn1.lvl, pkmn1.movePwr, pkmn1.SATK, pkmn2.SDEF);
			}
			else{ //Status
				if (type=="ATK") pkmn2.ATK=static_cast<int>(pkmn2.ATK*2/3);
				else if (type=="DEF") pkmn2.DEF=static_cast<int>(pkmn2.DEF*2/3);
				else if (type=="SATK") pkmn2.SATK=static_cast<int>(pkmn2.SATK*2/3);
				else if (type=="SDEF") pkmn2.SDEF=static_cast<int>(pkmn2.SDEF*2/3);
				else pkmn2.SPD=static_cast<int>(pkmn1.SPD*2/3);
			}
		}
		
		if (PKMN2FIRST) goto PKMN2F3;
		PKMN2F1:
		
		if(pkmn2.HP>0) {
			do {
				ind=rand() % 4;
			} while (pkmn2.moveset[ind] == "-");
			cout << pkmn2.name << " used " << pkmn2.moveset[ind] << "!" << endl;
			string type=pkmn2.moveType[ind];
			if(type=="Physical"){
				pkmn1.HP-=pkmn2.dmg(ind, pkmn2.lvl, pkmn2.movePwr, pkmn2.ATK, pkmn1.DEF);
			}
			else if(type=="Special"){
				pkmn1.HP-=pkmn2.dmg(ind, pkmn2.lvl, pkmn2.movePwr, pkmn2.SATK, pkmn1.SDEF);
			}
			else{ //Status
				if (type=="ATK" && pkmn1.ATK!=1) pkmn1.ATK=static_cast<int>(pkmn1.ATK*2/3);
				else if (type=="DEF" && pkmn1.DEF!=1) pkmn1.DEF=static_cast<int>(pkmn1.DEF*2/3);
				else if (type=="SATK" && pkmn1.SATK!=1) pkmn1.SATK=static_cast<int>(pkmn1.SATK*2/3);
				else if (type=="SDEF" && pkmn1.SDEF!=1) pkmn1.SDEF=static_cast<int>(pkmn1.SDEF*2/3);
				else pkmn1.SPD=static_cast<int>(pkmn1.SPD*2/3);
			}
		}
		
		if (PKMN2FIRST) goto PKMN2F2;
	}
	
	if (pkmn2.HP<=0){
		cout << "The wild " << pkmn2.name << " fainted!" << endl;
	}
	else{
		cout << pkmn1.name << " fainted!" << endl;
	}
	return 0;
}
