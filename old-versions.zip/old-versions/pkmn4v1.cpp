#include <iostream>
#include <fstream>
#include <cstdlib>
#include <limits> 
#include <string> 
#include <ios> 
using namespace std;

/*
To be implemented: (According to importance)
-ACC and EVA
-Special moves
-Types
-Status Effects
-Damage Modifiers
-Pokemon Selector
-Move selector
-Optimization of input (.txt files?)
-Indentation
-Modify pseudorandom code
*/

/*
Added in v3: 
-SPD determines first to attack
-Stats can not be lowered to 0
-Removed base stat objects
-Optimized setAllStats into constructors
-Optimized adding moves into setMove function
-Prints movesets, uses indices as input
*/

class pkmn{
	public:
		string name;
		string moveset[4];
		string moveType[4];
		int movePwr[4];
		int lvl;
		int HP;
		int ATK;
		int DEF;
		int SATK;
		int SDEF;
		int SPD;
		
		pkmn(string pName, int pLvl, int bHP, int bATK, int bDEF, int bSATK, int bSDEF, int bSPD){
			name=pName;
			lvl=pLvl;
			HP=setHP(bHP, lvl);
			ATK=setStat(bATK, lvl);
			DEF=setStat(bDEF, lvl);
			SATK=setStat(bSATK, lvl);
			SDEF=setStat(bSDEF, lvl);
			SPD=setStat(bSPD, lvl);
		}
		
		void findPKMN();
		
		void setMove(int ind, string move, string type, int pwr){
			moveset[ind]=move;
			moveType[ind]=type;
			movePwr[ind]=pwr;
		}
		
		int setHP(int bHP, int lvl){
			int HP=static_cast<int>(((2*bHP*lvl)/100)+10+lvl);
			return HP;
		}
		
		int setStat(int bStat, int lvl){
			int stat=static_cast<int>(((2*bStat*lvl)/100)+5);
			return stat;
		}
		
		int dmg(int i, int lvl, int movePwr[4], int A, int D){
			int t=static_cast<int>(((2*lvl / 5 + 2) * movePwr[i] * (A/D))/50 + 2);
			return t;
		}
};

void pkmn::findPKMN(){
	ifstream pkmnList;
	pkmnList.open("pkmnList.txt");
	
	if (!pkmnList) {
	    cout << "Unable to open pkmnList.txt";
	    exit(1);
	}
	
	cout << "Please input a Pokemon from Generation I." << endl;
	bool foundPKMN;
	string tmpName;
	string tmpLine;
	
	input:
	foundPKMN=false;
	cin >> tmpName;
	cout << endl << "Looking for your Pokemon..." << endl;
	
	pkmnList.clear();
	pkmnList.seekg(0, ios::beg);
	
	while (getline(pkmnList, tmpLine, ',')) {
        if (tmpLine == tmpName) {
        	foundPKMN=true;
        	cout << "Found it! What level would you like to start at?" << endl;
        	cin >> lvl;
        	for (int i=0; i<3; ++i) getline(pkmnList, tmpLine, ',');
			getline(pkmnList, tmpLine, ',');
			HP=setHP(stoi(tmpLine),lvl);
			getline(pkmnList, tmpLine, ',');
			ATK=setStat(stoi(tmpLine), lvl);
			getline(pkmnList, tmpLine, ',');
			DEF=setStat(stoi(tmpLine), lvl);
			getline(pkmnList, tmpLine, ',');
			SATK=setStat(stoi(tmpLine), lvl);
			getline(pkmnList, tmpLine, ',');
			SDEF=setStat(stoi(tmpLine), lvl);
			getline(pkmnList, tmpLine, ',');
			SPD=setStat(stoi(tmpLine), lvl);
            break;
        }
    }
    //18 10 9 11 10 11
    if(!foundPKMN){
    	cout << "Sorry, we couldn't find that. :<" << endl;
    	cout << "Please input a different Pokemon from Generation I." << endl;
    	goto input;
	}
}

int main(){
	/*
	pkmn pkmn2 ("PIKACHU",5,35,55,30,50,40,90);
	pkmn2.setMove(0, "Thunder Shock", "Physical", 40);
	pkmn2.setMove(1, "Growl", "ATK", 2/3);
	pkmn2.setMove(2, "Tail Whip", "DEF", 2/3);
	pkmn2.setMove(3, "-", "Physical", 40);
	*/
	
	/*
	pkmn pkmn2 ("CHARIZARD",20,78,84,78,109,85,100);
	pkmn2.setMove(0, "Dragon Claw", "Physical", 80);
	pkmn2.setMove(1, "Air Slash", "Special", 75);
	pkmn2.setMove(2, "Shadow Claw", "Physical", 70);
	pkmn2.setMove(3, "Growl", "ATK", 2/3);
	*/
	
	//pkmn pkmn1/2 (name, lvl, base HP, base ATK, base DEF, base SATK, base SDEF, base SPD)
	pkmn pkmn2 ("BULBASAUR",5,45,49,49,65,65,45);
	pkmn2.setMove(0, "Tackle", "Physical", 40);
	pkmn2.setMove(1, "Growl", "ATK", 2/3);
	pkmn2.setMove(2, "-", "Physical", 40);
	pkmn2.setMove(3, "-", "Physical", 40);
	
	pkmn pkmn1 ("CHARMANDER", 5, 39, 52, 42, 60, 50, 65);
	pkmn1.setMove(0, "Scratch", "Physical", 40);
	pkmn1.setMove(1, "Growl", "ATK", 2/3);
	pkmn1.setMove(2, "-", "Physical", 40);
	pkmn1.setMove(3, "-", "Physical", 40);
	
	pkmn1.findPKMN();
	
	
    
	/*DEBUG:
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << pkmn1.name << endl;
	cout << pkmn1.lvl << endl;
	cout << pkmn1.baseHP << endl;
	cout << pkmn1.baseATK << endl;
	cout << pkmn1.baseDEF << endl;
	cout << pkmn1.baseSATK << endl;
	cout << pkmn1.baseSDEF << endl;
	cout << pkmn1.baseSPD << endl;
	cout << pkmn1.HP << endl;
	cout << pkmn1.ATK << endl;
	cout << pkmn1.DEF << endl;
	cout << pkmn1.SATK << endl;
	cout << pkmn1.SDEF << endl;
	cout << pkmn1.SPD << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << pkmn2.name << endl;
	cout << pkmn2.lvl << endl;
	cout << pkmn2.baseHP << endl;
	cout << pkmn2.baseATK << endl;
	cout << pkmn2.baseDEF << endl;
	cout << pkmn2.baseSATK << endl;
	cout << pkmn2.baseSDEF << endl;
	cout << pkmn2.baseSPD << endl;
	cout << pkmn2.HP << endl;
	cout << pkmn2.ATK << endl;
	cout << pkmn2.DEF << endl;
	cout << pkmn2.SATK << endl;
	cout << pkmn2.SDEF << endl;
	cout << pkmn2.SPD << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;*/
	
	cout << endl << "A wild " << pkmn2.name << " appeared!" << endl;
	cout << "Go! " << pkmn1.name << "!" << endl;
	
	bool PKMN2FIRST;
	
	PKMN2F3:
	while (pkmn2.HP>0 && pkmn1.HP>0){
		int ind;

		cout << "--------------------------------------------------" << endl;
		cout << pkmn1.name << endl;
		cout << "HP: " << pkmn1.HP << " ATK: " << pkmn1.ATK << " DEF: " << pkmn1.DEF << " SATK: " << pkmn1.SATK << " SDEF: " << pkmn1.SDEF << " SPD: " << pkmn1.SPD << endl;
		cout << "--------------------------------------------------" << endl;
		cout << pkmn2.name << endl;
		cout << "HP: " << pkmn2.HP << " ATK: " << pkmn2.ATK << " DEF: " << pkmn2.DEF << " SATK: " << pkmn2.SATK << " SDEF: " << pkmn2.SDEF << " SPD: " << pkmn2.SPD << endl;
		cout << "--------------------------------------------------" << endl;
		
		if (pkmn2.SPD>pkmn1.SPD) {
			PKMN2FIRST=true;
			goto PKMN2F1;
		}
		PKMN2F2:
		
		if(pkmn1.HP>0) {
			cout << "What will " << pkmn1.name << " do?" << endl;
			
			cout << "~-~-~-~-~-~-~-~-~-~-~-~-~" << endl;
			cout << pkmn1.name << "'s Moveset: " << endl;
			for (int i=0; i<4; ++i) cout << " [" << i << "]  " << pkmn1.moveset[i] << endl;
			cout << "~-~-~-~-~-~-~-~-~-~-~-~-~" << endl;
			
			ind=0;
			do { 
				if (pkmn1.moveset[ind] == "-" || ind > 3 || ind < 0) cout << "    Input invalid, please enter the index of a valid move.\n";
				cin >> ind;
			} while(pkmn1.moveset[ind] == "-" || ind > 3 || ind < 0);
			
			cout << pkmn1.name << " used " << pkmn1.moveset[ind] << "!" << endl;
			string type=pkmn1.moveType[ind];
			
			if(type=="Physical"){
				pkmn2.HP-=pkmn1.dmg(ind, pkmn1.lvl, pkmn1.movePwr, pkmn1.ATK, pkmn2.DEF);
			}
			
			else if(type=="Special"){
				pkmn2.HP-=pkmn1.dmg(ind, pkmn1.lvl, pkmn1.movePwr, pkmn1.SATK, pkmn2.SDEF);
			}
			
			else{ //Status
				if (type=="ATK") pkmn2.ATK=static_cast<int>(pkmn2.ATK*2/3);
				else if (type=="DEF") pkmn2.DEF=static_cast<int>(pkmn2.DEF*2/3);
				else if (type=="SATK") pkmn2.SATK=static_cast<int>(pkmn2.SATK*2/3);
				else if (type=="SDEF") pkmn2.SDEF=static_cast<int>(pkmn2.SDEF*2/3);
				else pkmn2.SPD=static_cast<int>(pkmn1.SPD*2/3);
			}
		}
		
		if (PKMN2FIRST) goto PKMN2F3;
		PKMN2F1:
		
		if(pkmn2.HP>0) {
			
			do {
				ind=rand() % 4;
			} while (pkmn2.moveset[ind] == "-");
			
			cout << pkmn2.name << " used " << pkmn2.moveset[ind] << "!" << endl;
			string type=pkmn2.moveType[ind];
			
			if(type=="Physical"){
				pkmn1.HP-=pkmn2.dmg(ind, pkmn2.lvl, pkmn2.movePwr, pkmn2.ATK, pkmn1.DEF);
			}
			
			else if(type=="Special"){
				pkmn1.HP-=pkmn2.dmg(ind, pkmn2.lvl, pkmn2.movePwr, pkmn2.SATK, pkmn1.SDEF);
			}
			
			else{ //Status
				if (type=="ATK" && pkmn1.ATK!=1) pkmn1.ATK=static_cast<int>(pkmn1.ATK*2/3);
				else if (type=="DEF" && pkmn1.DEF!=1) pkmn1.DEF=static_cast<int>(pkmn1.DEF*2/3);
				else if (type=="SATK" && pkmn1.SATK!=1) pkmn1.SATK=static_cast<int>(pkmn1.SATK*2/3);
				else if (type=="SDEF" && pkmn1.SDEF!=1) pkmn1.SDEF=static_cast<int>(pkmn1.SDEF*2/3);
				else pkmn1.SPD=static_cast<int>(pkmn1.SPD*2/3);
			}
		}
		
		if (PKMN2FIRST) goto PKMN2F2;
	}
	
	if (pkmn2.HP<=0){
		cout << "The wild " << pkmn2.name << " fainted!" << endl;
	}
	else{
		cout << pkmn1.name << " fainted!" << endl;
	}
	return 0;
}
